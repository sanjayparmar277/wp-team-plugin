<table id="repeatable-fieldset-one" class="widefat fixed" cellspacing="0" style="width:100%;"> 
	<thead> 
		<tr> 
			<th style="width:50px;" scope="col">Sr. No.</th>
			<th style="" scope="col">Name</th>
			<th width="" scope="col">Gender</th>
			<th width="" scope="col">Birthdate</th>
			<th width="" scope="col">Age</th>
			<th width="" scope="col">Biodata</th>
			<th width="8%" scope="col">Action</th>
		</tr> 
	</thead> 
	<tbody> 


	<?php 

	// set a variable so we can append it to each row 
	$i = 1; 

	//echo "<pre>"; print_r($team_repeatable_fields); die;
	foreach ( $team_repeatable_fields as $field ) {
	?>

	<tr class="single-team-row ui-state-default"> 

	    <td> 
		    <label for="_team_member[<?php echo $i;?>][sr_no]"> 
		    <input name="_team_member[<?php echo $i;?>][sr_no]" id="_team_member[<?php echo $i;?>][sr_no]" class="components-text-control__input team_sr_no_number" disabled="disabled" type="text" value="# <?php echo $i;?>" /> 
		    </label>    
	    </td> 

	    <td> 
		    <label for="_team_member[<?php echo $i;?>][tm_name]"> 
		    <input name="_team_member[<?php echo $i;?>][tm_name]" class="components-text-control__input" id="_team_member[<?php echo $i;?>][tm_name]" type="text" size="36" value="<?php echo esc_attr( $field['tm_name'] );?>" />
		    </label> 
	    </td> 

	    <td> 
	    	<!-- title field --> 
		    <div class="playbackformat-holder"> 

			    <label for="_team_member[<?php echo $i;?>][tm_gender][male]"> 
			    <input type="radio" id="_team_member[<?php echo $i;?>][tm_gender][male]" name="_team_member[<?php echo $i;?>][tm_gender]" value="male" <?php checked( $field['tm_gender'], 'male' ); ?> />Male 
			    </label> 
			    <label for="_team_member[<?php echo $i;?>][tm_gender][female]"> 
			    <input type="radio" id="_team_member[<?php echo $i;?>][tm_gender][female]" name="_team_member[<?php echo $i;?>][tm_gender]" value="female" <?php checked( $field['tm_gender'], 'female' ); ?> />Female 
			    </label><br>

		    </div> 
	    </td> 

	    <td>
	    	<!-- <textarea name="_team_member[<?php echo $i;?>][tm_birthdate]" id="_team_member[<?php echo $i;?>][tm_birthdate]" class="components-text-control__input"><?php echo esc_html( $field['tm_birthdate'] );?></textarea> -->
	    	<input name="_team_member[<?php echo $i;?>][tm_birthdate]" id="_team_member[<?php echo $i;?>][tm_birthdate]" class="components-text-control__input datepicker" type="text" size="36" value="<?php echo esc_html( $field['tm_birthdate'] );?>" />
	    </td>

	    <td>
	    	<input name="_team_member[<?php echo $i;?>][tm_age]" id="_team_member[<?php echo $i;?>][tm_age]" class="components-text-control__input player_age" type="text" size="36" value="<?php echo esc_html( $field['tm_age'] );?>" />
	    </td>

	    <td>
	    <textarea id="_team_member[<?php echo $i;?>][tm_biodata]" name="_team_member[<?php echo $i;?>][tm_biodata]" class="components-textarea-control__input"><?php echo esc_html( $field['tm_biodata'] );?></textarea>
	    </td> 

	    <td>
	    <a class="button remove-row" href="#">Remove</a>
	    </td> 

	</tr> 

	<?php $i++; } ?>


	<!-- empty hidden one for jQuery --> 
	<tr class="empty-row screen-reader-text single-team-row"> 

	    <td> 
		    <label for="_team_member[%s][sr_no]"> 
		    <input name="_team_member[%s][sr_no]" id="_team_member[%s][sr_no]" class="components-text-control__input team_sr_no_number" disabled="disabled" type="text" value="" /> 
		    </label>    
	    </td> 

	    <td> 
		    <label for="_team_member[%s][tm_name]"> 
		    <input name="_team_member[%s][tm_name]" class="components-text-control__input" id="_team_member[%s][tm_name]" type="text" size="36" value="" /> 
		    </label> 
	    </td> 

	    <td> 
		    <!-- title field --> 
		    <div class="playbackformat-holder"> 
			    <label for="_team_member[%s][tm_gender][male]"> 
			    <input type="radio" id="_team_member[%s][tm_gender][male]" name="_team_member[%s][tm_gender]" value="male" <?php checked( 'male', 'male' ); ?> />Male 
			    </label> 
			    <label for="_team_member[%s][tm_gender][female]"> 
			    <input type="radio" id="_team_member[%s][tm_gender][female]" name="_team_member[%s][tm_gender]" value="female" />Female 
			    </label><br>
		    </div> 
		    <!-- drop down or checkbox's with release formats --> 
	    </td> 

	    <td>
	    	<label for="_team_member[%s][tm_birthdate]">
	    		<input name="_team_member[%s][tm_birthdate]" class="components-text-control__input datepicker" id="_team_member[%s][tm_birthdate]" type="text" size="36" value="" />
	    	</label>
	    </td>

	    <td>
	    	<label for="_team_member[%s][tm_age]"> 
		    	<input name="_team_member[%s][tm_age]" class="components-text-control__input player_age" id="_team_member[%s][tm_age]" type="text" size="36" value="" /> 
		    </label> 
	    </td>

	    <td>
	    <textarea id="_team_member[%s][tm_biodata]" name="_team_member[%s][tm_biodata]" class="components-textarea-control__input"></textarea>
	    </td> 


	    <td>
	    <a class="button remove-row" href="#">Remove</a>
	    </td> 

	</tr> 

	</tbody> 
</table> 

<p id="add-row-p-holder"><a id="add-row" class="button" href="#">Add New Team Member</a></p> 