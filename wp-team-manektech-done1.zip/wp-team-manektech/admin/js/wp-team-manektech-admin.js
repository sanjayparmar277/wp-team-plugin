(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	jQuery(document).ready(function( $ ){
	   	/*$( '#add-row' ).on('click', function() {
	        var row = $( '.empty-row.screen-reader-text' ).clone(true);
	        row.removeClass( 'empty-row screen-reader-text' );
	        row.insertBefore( '#repeatable-fieldset-one tbody>tr:last' );
	        return false;
	    });*/

	    $( '#add-row' ).click(function() { 
			var rowCount = $('#repeatable-fieldset-one').find('.single-team-row').not(':last-child').size(); 
			var newRowCount = rowCount + 1;

			var row = $( '.empty-row.screen-reader-text' ).clone(true); 

			// Loop through all inputs
			row.find('input, textarea, label').each(function(){ 

			    if ( !! $(this).attr('id') )
			        $(this).attr('id',  $(this).attr('id').replace('[%s]', '[' + newRowCount + ']') );  // Replace for

			    if ( !! $(this).attr('name') )
			        $(this).attr('name',  $(this).attr('name').replace('[%s]', '[' + newRowCount + ']') );  // Replace for

			    if ( !! $(this).attr('for') )
			        $(this).attr('for',  $(this).attr('for').replace('[%s]', '[' + newRowCount + ']') );  // Replace for

			});

			row.removeClass( 'empty-row screen-reader-text' ).find('.team_sr_no_number').val('# '+newRowCount);
			row.insertBefore( '.empty-row' ); 

			// if row count hits 10, hide the add row button 
			if ( newRowCount == 10 ) { 
				jQuery('#add-row').fadeOut(); 
			} 

			var row = jQuery( '.single-team-row' ); 
			var i = 1;
			row.find('.datepicker').each(function(index){
			    jQuery('[id="_team_member['+ i +'][tm_birthdate]"]').datepicker({
			        onSelect: function(value, ui) {
			            var today = new Date(), 
			                dob = new Date(value), 
			                age = new Date(today - dob).getFullYear() - 1970;
							jQuery(this).closest('tr').find('.player_age').val(age);
			            console.log(name);
			        },
			        maxDate: '+0d',
			        //setDate: new Date(),
			        defaultDate: '-18yr',
			        changeMonth: true,
			        changeYear: true
			    });
			    i++;
			});

			return false; 
		});
		
		$( '.remove-row' ).on('click', function() {
			$(this).parents('tr').remove();
		    return false;
		});

	});

})( jQuery );
