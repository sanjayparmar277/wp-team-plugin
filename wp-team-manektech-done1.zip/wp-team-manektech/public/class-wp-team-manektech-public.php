<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       #
 * @since      1.0.0
 *
 * @package    Wp_Team_Manektech
 * @subpackage Wp_Team_Manektech/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wp_Team_Manektech
 * @subpackage Wp_Team_Manektech/public
 * @author     Sonali Prajapati <sonaliprajapati_1905@yahoo.com>
 */
class Wp_Team_Manektech_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Team_Manektech_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Team_Manektech_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wp-team-manektech-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Team_Manektech_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Team_Manektech_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wp-team-manektech-public.js', array( 'jquery' ), $this->version, false );

	}


	/**
	 * Register all shortcodes
	 *
	 * @return null
	 */
	function register_shortcodes() {
	    add_shortcode( 'Display', array($this, 'display_team') );
	}

	/**
	 * Team Shortcode Callback
	 * 
	 * @param Array $atts
	 *
	 * @return string
	 */
	public function display_team( $atts ) {
	    global $wp_query, $post;

	    $atts = shortcode_atts( array(
	        'team' => ''
	    ), $atts );

	    $teamParam = sanitize_title( $atts['team']); 
	    $postType = 'team';

	    //check if params value is slug in shortcode
	    if (!is_numeric($teamParam)) {
	    	if ( $post = get_page_by_path( $teamParam, OBJECT, $postType ) ){
			    $teamParam = $post->ID;
		    } else {
			    $teamParam = 0;
			}
	    }

	    //Query
		$loop = new WP_Query( array(
	        'post_type'         => $postType,
	        'p'					=> $teamParam,
	    ) );

	    if( ! $loop->have_posts() ) {
	        return false;
	    }

	    while( $loop->have_posts() ) {
	        $loop->the_post();
	        $team_repeatable_fields = get_post_meta($post->ID, 'team_repeatable_fields', true); 
			//echo "<pre>"; print_r($team_repeatable_fields); die;
	        ?>
			<section class="u-align-center u-clearfix u-custom-typography u-image u-shading u-section-1" id="team-section">
		      <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
		        <h1 class="u-text u-text-1"><?php the_title(); ?></h1>
		        <?php $featured_img_url = get_the_post_thumbnail_url($post->ID, 'full');  ?>
				<img src="<?php echo $featured_img_url; ?>" alt="" class="u-align-left u-expanded-width u-image u-image-1">
		        <p class="u-text u-text-2"><?php the_content() ?></p>
		        <div class="u-clearfix u-expanded-width u-gutter-30 u-layout-wrap u-layout-wrap-1">
		          <div class="u-gutter-0 u-layout">
		            <div class="u-layout-row">
						<?php foreach ( $team_repeatable_fields as $field ) { ?>
							<div class="u-align-center u-container-style u-grey-5 u-layout-cell u-left-cell u-size-20 u-size-20-md u-layout-cell-1">
								<div class="u-container-layout u-valign-top u-container-layout-1">
									<h5 class="u-align-center u-text u-text-3"><?php echo $field['tm_name']; ?></h5>
									<p class="u-align-center u-text u-text-body-color u-text-4">Gender: <?php echo $field['tm_gender']; ?></p>
									<p class="u-align-center u-text u-text-body-color u-text-4">Birth Date: <?php echo $field['tm_birthdate']; ?></p>
									<p class="u-align-center u-text u-text-body-color u-text-4">Age: <?php echo $field['tm_age']; ?></p>
									<p class="u-align-center u-text u-text-body-color u-text-4">Biodata: <?php echo $field['tm_biodata']; ?></p>
								</div>
							</div>
						<?php } ?>

		            </div>
		          </div>
		        </div>
		      </div>
		    </section>
	        <?php
	    }

	    wp_reset_postdata();
	}

}
