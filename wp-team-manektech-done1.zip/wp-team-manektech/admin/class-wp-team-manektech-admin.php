<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       #
 * @since      1.0.0
 *
 * @package    Wp_Team_Manektech
 * @subpackage Wp_Team_Manektech/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wp_Team_Manektech
 * @subpackage Wp_Team_Manektech/admin
 * @author     Sonali Prajapati <sonaliprajapati_1905@yahoo.com>
 */
class Wp_Team_Manektech_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Team_Manektech_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Team_Manektech_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wp-team-manektech-admin.css', array(), $this->version, 'all' );
		wp_enqueue_style( 'jquery-ui', plugin_dir_url( __FILE__ ) . 'css/jquery-ui.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Team_Manektech_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Team_Manektech_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wp-team-manektech-admin.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( 'jquery-ui', plugin_dir_url( __FILE__ ) . 'js/jquery-ui.js', array( 'jquery' ), $this->version, false );

	}

	// Register Custom Team
	public function team_post_type() {

		$labels = array(
			'name'                  => _x( 'Teams', 'Team General Name', 'wtm' ),
			'singular_name'         => _x( 'Team', 'Team Singular Name', 'wtm' ),
			'menu_name'             => __( 'Teams', 'wtm' ),
			'name_admin_bar'        => __( 'Team', 'wtm' ),
			'archives'              => __( 'Item Archives', 'wtm' ),
			'attributes'            => __( 'Item Attributes', 'wtm' ),
			'parent_item_colon'     => __( 'Parent Item:', 'wtm' ),
			'all_items'             => __( 'All Items', 'wtm' ),
			'add_new_item'          => __( 'Add New Item', 'wtm' ),
			'add_new'               => __( 'Add New', 'wtm' ),
			'new_item'              => __( 'New Item', 'wtm' ),
			'edit_item'             => __( 'Edit Item', 'wtm' ),
			'update_item'           => __( 'Update Item', 'wtm' ),
			'view_item'             => __( 'View Item', 'wtm' ),
			'view_items'            => __( 'View Items', 'wtm' ),
			'search_items'          => __( 'Search Item', 'wtm' ),
			'not_found'             => __( 'Not found', 'wtm' ),
			'not_found_in_trash'    => __( 'Not found in Trash', 'wtm' ),
			'featured_image'        => __( 'Featured Image', 'wtm' ),
			'set_featured_image'    => __( 'Set featured image', 'wtm' ),
			'remove_featured_image' => __( 'Remove featured image', 'wtm' ),
			'use_featured_image'    => __( 'Use as featured image', 'wtm' ),
			'insert_into_item'      => __( 'Insert into item', 'wtm' ),
			'uploaded_to_this_item' => __( 'Uploaded to this item', 'wtm' ),
			'items_list'            => __( 'Items list', 'wtm' ),
			'items_list_navigation' => __( 'Items list navigation', 'wtm' ),
			'filter_items_list'     => __( 'Filter items list', 'wtm' ),
		);
		$args = array(
			'label'                 => __( 'Team', 'wtm' ),
			'description'           => __( 'Team Description', 'wtm' ),
			'labels'                => $labels,
			'supports'				=> array(
											'title',
											'editor',
											'excerpt',
											'custom-fields',
											'thumbnail',
											'page-attributes'
										),
			'hierarchical'          => false,
			'public'                => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => 5,
			'show_in_admin_bar'     => true,
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => true,
			'exclude_from_search'   => false,
			'publicly_queryable'    => true,
			'show_in_rest' 			=> true,
			'capability_type'       => 'page',
			'rewrite'				=> array('slug', 'team'),
		);
		register_post_type( 'team', $args );

		//Register Custom taxonomy "Team Category"
		$taxonomy_label = array(
			'name'                       => _x( 'Team Category', 'Team General Name', 'wtm' ),
			'singular_name'              => _x( 'Team Category', 'Team Singular Name', 'wtm' ),
			'menu_name'                  => __( 'Team Category', 'wtm' ),
			'all_items'                  => __( 'All Items', 'wtm' ),
			'parent_item'                => __( 'Parent Item', 'wtm' ),
			'parent_item_colon'          => __( 'Parent Item:', 'wtm' ),
			'new_item_name'              => __( 'New Item Name', 'wtm' ),
			'add_new_item'               => __( 'Add New Item', 'wtm' ),
			'edit_item'                  => __( 'Edit Item', 'wtm' ),
			'update_item'                => __( 'Update Item', 'wtm' ),
			'view_item'                  => __( 'View Item', 'wtm' ),
			'separate_items_with_commas' => __( 'Separate items with commas', 'wtm' ),
			'add_or_remove_items'        => __( 'Add or remove items', 'wtm' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'wtm' ),
			'popular_items'              => __( 'Popular Items', 'wtm' ),
			'search_items'               => __( 'Search Items', 'wtm' ),
			'not_found'                  => __( 'Not Found', 'wtm' ),
			'no_terms'                   => __( 'No items', 'wtm' ),
			'items_list'                 => __( 'Items list', 'wtm' ),
			'items_list_navigation'      => __( 'Items list navigation', 'wtm' ),
		);
		$args = array(
			'labels'                     => $taxonomy_label,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'show_in_rest'               => true,
		);
		register_taxonomy( 'team-category', array( 'team' ), $args );

	}

	public function wtm_add_meta_box() {
	    add_meta_box( 'team_repeatable_fields', 'Team Players', array($this, 'repeatable_meta_box_display'), 'team', 'normal', 'default');
	    add_meta_box( 'team_shortcode', __( 'Shortcode', 'wtm' ), array($this, 'wtm_render_shortcode_meta_box'), 'team', 'side' );
	}

	public function repeatable_meta_box_display( $post ) {

		$team_repeatable_fields = get_post_meta($post->ID, 'team_repeatable_fields', true); 

		if ( empty( $team_repeatable_fields ) ){
			$team_repeatable_fields = array();
		    $team_repeatable_fields[0] = array (
		                                'tm_name' => '',
		                                'tm_gender' => 'male',
		                                'tm_birthdate' => '',
		                                'tm_age' => '',
		                                'tm_biodata' => '' 
		                            );
		}

		wp_nonce_field( 'wtm_repeatable_meta_box_nonce', 'wtm_repeatable_meta_box_nonce' ); 
		
		//render repeater html file here
		require_once plugin_dir_path( __FILE__ ) . 'partials/wp-team-repeater-fields.php';

	}

	public function wtm_repeatable_meta_box_save($post_id) {

		if ( ! isset( $_POST['wtm_repeatable_meta_box_nonce'] ) || 
		!wp_verify_nonce( $_POST['wtm_repeatable_meta_box_nonce'], 'wtm_repeatable_meta_box_nonce' ) ){
			return;
		}

		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){
			return;
		}

		if (!current_user_can('edit_post', $post_id)){
			return; 
		}

		$clean = array(); 

		if  ( isset ( $_POST['_team_member'] ) && is_array( $_POST['_team_member'] ) ) :

		    foreach ( $_POST['_team_member'] as $i => $team ){

			    // skip the hidden "to copy" div
			    if( $i == '%s' ){ 
			        continue;
			    }

				$tm_genders = array ( 'male', 'female' );

			    $clean[] = array(
					        'tm_name' => isset( $team['tm_name'] ) ? sanitize_text_field( $team['tm_name'] ) : null,
					        'tm_gender' => isset( $team['tm_gender'] ) && in_array( $team['tm_gender'], $tm_genders ) ? $team['tm_gender'] : null,
					        'tm_birthdate' => isset( $team['tm_birthdate'] ) ? sanitize_text_field( $team['tm_birthdate'] ) : null,
					        'tm_age' => isset( $team['tm_age'] ) ? sanitize_text_field( $team['tm_age'] ) : null,
					        'tm_biodata' => isset( $team['tm_biodata'] ) ? sanitize_text_field( $team['tm_biodata'] ) : null,
				        );

			}

		endif;

		// save team data 
		if ( ! empty( $clean ) ) {
		    update_post_meta( $post_id, 'team_repeatable_fields', $clean ); 
		} else{
		    delete_post_meta( $post_id, 'team_repeatable_fields' ); 
		}

	}

	function wtm_render_shortcode_meta_box() {
	    global $post;

	    $sc = '[Display team='.$post->ID.']';
	    echo '<p>'.__('Use this shortcode for displaying the team in other pages','wtm').'</p>';
	    echo '<div style="background-color: #F1F1F1;padding: 10px;font-size: 20px;">'; print_r( $sc ); echo '</div>';
	}

	public function wtm_posts_menu_columns( $defaults ) {
	    $result = array();
	    $result['cb'] = '<input type="checkbox" />';
	    $result['title'] = __('Team Name', 'wtm');
	    $result['featured_image'] = 'Team Logo';
	    $result['shortcode'] = __('Shortcode', 'wtm');	    
	    unset( $defaults['cb'] );
	    unset( $defaults['title'] );
	    foreach( $defaults as $key => $value ) {
	        $result[ $key ] = $value;
	    }
	    return $result;
	}

	public function wtm_posts_menu_columns_echo( $column_name, $post_id ) {
	    
	    //set short code in table
	    if ( $column_name == 'shortcode' ) {
	        echo '[Display team='.$post_id.']';
	    }

	    //set Team logo (featured image)
	    if ($column_name == 'featured_image') {
	        $post_featured_image = $this->wtm_team_logo($post_id);
	        if ($post_featured_image) {
	            echo '<img src="' . $post_featured_image . '" width="100" height="100"/>';
	        }
	    }

	}

	public function wtm_team_logo($post_id) {
	    $post_thumbnail_id = get_post_thumbnail_id($post_id);
	    if ($post_thumbnail_id) {
	        $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'featured_preview');
	        return $post_thumbnail_img[0];
	    }
	}

}
